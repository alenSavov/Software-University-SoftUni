﻿namespace P01_StudentSystem.Data
{
    public class Configuration
    {
        public const string ConnectionString = @"Server=DESKTOP-U67U5UI\SQLEXPRESS;Database=StudentSytem;Integrated Security=True";
    }
}
