﻿namespace Chushka.Web.Infrastructure
{
    public static class GlobalConstants
    {
        public static readonly string AdminRole = "Admin";
        public static readonly string UserRole = "User";
    }
}