﻿using System;
using System.Collections.Generic;
using System.Text;


public interface IIdentable
{
    string Id { get; }
}

